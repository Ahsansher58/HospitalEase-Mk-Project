@extends('layouts/layoutMaster')

@section('title', 'Add Hospital')

<!-- Vendor Styles -->
@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/select2/select2.scss',
  'resources/assets/vendor/libs/animate-css/animate.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
  'resources/assets/vendor/libs/@form-validation/form-validation.scss'
])
@endsection
<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/select2/select2.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js',
  'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/@form-validation/popular.js',
  'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
  'resources/assets/vendor/libs/@form-validation/auto-focus.js'
])
@endsection

<!-- Page Scripts -->
@section('page-script')
@vite([
  'resources/assets/js/forms-selects.js',
  'resources/assets/js/form-validation.js'
])
@endsection
@section('content')

<!-- Ajax Sourced Server-side -->
<div class="card">
  <h5 class="card-header">Add Hospitals</h5>
  <div class="card-body">
  <form id="formValidationExamples" novalidate>
  <div class="row">
  <div class="col-md-6 mb-4">
            <label class="form-label" for="formValidationHospital">Name of Hospital</label>
            <input class="form-control typeahead" type="text" placeholder="Name of Hospital" id="formValidationHospital" name="formValidationHospital" autocomplete="off" />
          </div>
          <div class="col-md-6">
          <label class="form-label" for="formValidationCity">City</label>
          <select id="formValidationCity" name="formValidationCity" class="select2 form-select" data-allow-clear="true">
          <option value="">Select City</option>
              <option value="CH">Chennai</option>
              <option value="BA">Bangalore</option>
            </select>
</div>
<div class="col-md-6 mb-4">
          <label class="form-label" for="formValidationState">City</label>
          <select id="formValidationState" name="formValidationState" class="select2 form-select" data-allow-clear="true">
          <option value="">Select State</option>
              <option value="TA">Tamilnadu</option>
              <option value="KA">Karnataka</option>
            </select>
</div>
            <div class="col-md-6 mb-4">
            <label class="form-label" for="formValidationSelect2">Country</label>
            <select id="formValidationSelect2" name="formValidationSelect2" class="form-select select2" data-allow-clear="true">
              <option value="">Select</option>
              <option value="Australia">Australia</option>
              <option value="Bangladesh">Bangladesh</option>
              <option value="Belarus">Belarus</option>
              <option value="Brazil">Brazil</option>
              <option value="Canada">Canada</option>
              <option value="China">China</option>
              <option value="France">France</option>
              <option value="Germany">Germany</option>
              <option value="India">India</option>
              <option value="Indonesia">Indonesia</option>
              <option value="Israel">Israel</option>
              <option value="Italy">Italy</option>
              <option value="Japan">Japan</option>
              <option value="Korea">Korea, Republic of</option>
              <option value="Mexico">Mexico</option>
              <option value="Philippines">Philippines</option>
              <option value="Russia">Russian Federation</option>
              <option value="South Africa">South Africa</option>
              <option value="Thailand">Thailand</option>
              <option value="Turkey">Turkey</option>
              <option value="Ukraine">Ukraine</option>
              <option value="United Arab Emirates">United Arab Emirates</option>
              <option value="United Kingdom">United Kingdom</option>
              <option value="United States">United States</option>
            </select>
          </div>
          <div class="col-md-6 mb-4">
          <label class="form-label" for="formValidationContact">Contact Number</label>
          <input class="form-control typeahead" type="number" placeholder="Contact Number" id="formValidationContact" name="formValidationContact" autocomplete="off" />
</div>
<div class="col-md-6 mb-4">
          <label class="form-label" for="formValidationEmail">Email Address</label>
          <input class="form-control typeahead" type="email" placeholder="Email Address" id="formValidationEmail" name="formValidationEmail" autocomplete="off" />
</div>
        
</div>
<button type="submit" class="btn btn-primary export-csv waves-effect mt-3">Submit <i class="menu-icon tf-icons ti ti-arrow-right ms-1"></i></button>
</form>
  </div>
  </div>
<!--/ Ajax Sourced Server-side -->

@endsection
