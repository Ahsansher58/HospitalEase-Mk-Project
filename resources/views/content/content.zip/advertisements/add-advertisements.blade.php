@extends('layouts/layoutMaster')

@section('title', 'Add Advertisements')

<!-- Vendor Styles -->
@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/select2/select2.scss',
  'resources/assets/vendor/libs/animate-css/animate.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
  'resources/assets/vendor/libs/@form-validation/form-validation.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
  'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
  'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
  'resources/assets/vendor/libs/pickr/pickr-themes.scss'
])
@endsection
<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/select2/select2.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js',
  'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/@form-validation/popular.js',
  'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
  'resources/assets/vendor/libs/@form-validation/auto-focus.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js',
  'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
  'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
  'resources/assets/vendor/libs/pickr/pickr.js'
])
@endsection

<!-- Page Scripts -->
@section('page-script')
@vite([
  'resources/assets/js/forms-selects.js',
  'resources/assets/js/forms-selects.js',
  'resources/assets/js/forms-pickers.js',
  'resources/assets/js/form-validation.js'
])
<!-- Place the first <script> tag in your HTML's <head> -->
<script src="https://cdn.ckeditor.com/ckeditor5/17.0.0/classic/ckeditor.js"></script>

<!-- Place the following <script> and <textarea> tags your HTML's <body> -->
<script>
ClassicEditor
	.create( document.querySelector( '#editor' ) )
	.catch( error => {
		console.error( error );
	} );
				
</script>
@endsection

@section('content')

<!-- Ajax Sourced Server-side -->
<div class="card">
  <h5 class="card-header">Add Advertisements</h5>
  <div class="card-body">
  <form id="formValidationExamples" novalidate>
  <div class="row">
  <div class="col-md-6 mb-4">
            <label class="form-label" for="formValidationHospital">Campaign Name</label>
            <input class="form-control typeahead" type="text" placeholder="Campaign Name" id="formValidationHospital" name="formValidationHospital" autocomplete="off" />
          </div>
          <div class="col-md-6  mb-4">
          <label class="form-label" for="formValidationCity">Placement</label>
          <select id="formValidationCity" name="formValidationCity" class="select2 form-select" data-allow-clear="true">
          <option value="">Select Placement</option>
              <option value="CH">Placement1</option>
              <option value="BA">Placement2</option>
            </select>
</div>
          <div class="col-md-12  mb-4">
      <label class="form-label" for="multicol-last-name">Choose Image or Insert Code</label>
      <div id="editor">

	</div>
      </div>
<div class="col-md-6 mb-4">
          <label class="form-label" for="formValidationEmail">Start Date & Time</label>
          <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="flatpickr-datetime" />
</div>
<div class="col-md-6 mb-4">
          <label class="form-label" for="formValidationEmail"> End Date & Time</label>
          <input type="text" class="form-control" placeholder="YYYY-MM-DD HH:MM" id="flatpickr-datetime2" />
</div>
        
</div>
<button type="submit" class="btn btn-primary export-csv waves-effect mt-3">Submit <i class="menu-icon tf-icons ti ti-arrow-right ms-1"></i></button>
</form>
  </div>
  </div>
<!--/ Ajax Sourced Server-side -->

@endsection
