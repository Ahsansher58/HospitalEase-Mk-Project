@extends('layouts/layoutMaster')

@section('title', 'Main Categories')

<!-- Vendor Styles -->
@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/select2/select2.scss',
  'resources/assets/vendor/libs/animate-css/animate.scss',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection
<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/select2/select2.js',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

<!-- Page Scripts -->
@section('page-script')
@vite([
  'resources/assets/js/tables-datatables-advanced.js',
  'resources/assets/js/forms-selects.js',
  'resources/assets/js/extended-ui-sweetalert2.js',
])
@endsection
@section('content')

<!-- Ajax Sourced Server-side -->
<div class="card mb-3">
  <h5 class="card-header">Add Main Categories</h5>
  <div class="card-body">
  <div class="add-cat">
  <div class="row">
  <div class="col-lg-5">
  <label class="form-label" for="formValidationHospital">Sort Order</label>
  <input class="form-control typeahead" type="number" placeholder="Sort Order" id="formValidationHospital" name="formValidationHospital" autocomplete="off" />
</div>
<div class="col-lg-5">
<label class="form-label" for="formValidationHospital">Category Name</label>
<input class="form-control typeahead" type="text" placeholder="Enter Category Name" id="formValidationHospital" name="formValidationHospital" autocomplete="off" /> 
</div>
<div class="col-lg-2">
<button type="button" class="btn btn-primary waves-effect w-100 mt-4" id="success">Submit</button> 
</div>
</div>
</div>
</div>
</div>
<div class="card">
  <h5 class="card-header">Manage Main Categories</h5>
  <div class="card-body">
  <div class="card-datatable text-nowrap position-relative">
  <table class="datatables-ajax6 table dataTables_wrapper dt-bootstrap5 no-footer">
      <thead>
        <tr>
          <th>Sort Order Number</th>
          <th>Category Name</th>
          <th>Action</th>
        </tr>
      </thead>
    </table>
</div>
  </div>
</div>
<!--/ Ajax Sourced Server-side -->

@endsection
