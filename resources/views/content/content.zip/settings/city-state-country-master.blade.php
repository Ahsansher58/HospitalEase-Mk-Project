@extends('layouts/layoutMaster')

@section('title', 'City, State and Country Masters')

<!-- Vendor Styles -->
@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/select2/select2.scss',
  'resources/assets/vendor/libs/tagify/tagify.scss',
  'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.scss',
  'resources/assets/vendor/libs/typeahead-js/typeahead.scss',
  'resources/assets/vendor/libs/animate-css/animate.scss',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection
<!-- Vendor Scripts -->
@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/select2/select2.js',
  'resources/assets/vendor/libs/tagify/tagify.js',
  'resources/assets/vendor/libs/bootstrap-select/bootstrap-select.js',
  'resources/assets/vendor/libs/typeahead-js/typeahead.js',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

<!-- Page Scripts -->
@section('page-script')
@vite([
  'resources/assets/js/tables-datatables-advanced.js',
  'resources/assets/js/forms-selects.js',
  'resources/assets/js/forms-tagify.js',
  'resources/assets/js/forms-typeahead.js',
  'resources/assets/js/extended-ui-sweetalert2.js'
])
@endsection
@section('content')

<!-- Ajax Sourced Server-side -->
<div class="card mb-3">
  <h5 class="card-header">Add City, State and Country Masters</h5>
  <div class="card-body">
  <div class="add-cat">
  <div class="row">
  <div class="col-lg-3">
  <label class="form-label" for="formValidationHospital">City</label>
  <input id="TagifyCustomInlineSuggestion" name="TagifyCustomInlineSuggestion" class="form-control" placeholder="Select City" value="Chennai">
</div>
  <div class="col-lg-3">
  <label class="form-label" for="formValidationHospital2">State</label>
  <input id="TagifyCustomInlineSuggestion2" name="TagifyCustomInlineSuggestion2" class="form-control" placeholder="Select State" value="Tamilnadu">
</div>
<div class="col-lg-3">
<label class="form-label" for="formValidationHospital3">Country</label>
<input id="TagifyCustomInlineSuggestion3" name="TagifyCustomInlineSuggestion3" class="form-control" placeholder="Select Country" value="India">
</div>
<div class="col-lg-3">
<button type="submit" class="btn btn-primary waves-effect w-100 mt-4">Submit</button> 
</div>
</div>
</div>
</div>
</div>
<div class="card">
  <h5 class="card-header">Manage City, State and Country Masters</h5>
  <div class="card-body">
  <div class="card-datatable text-nowrap position-relative">
  <table class="datatables-ajax8 table dataTables_wrapper dt-bootstrap5 no-footer">
      <thead>
        <tr>
          <th>City</th>
          <th>State</th>
          <th>Country</th>
          <th>Action</th>
        </tr>
      </thead>
    </table>
</div>
  </div>
</div>
<!--/ Ajax Sourced Server-side -->

@endsection
